
class Bank :
    import json
    data=[]
    # balance=[]
    def __init__(self):
            self.Username=[]
            self.balance=1000
            self.mobile_number=""
            self.amount=0
            self.menu()
        
    def menu(self):
         while True:
            bank=input(""" 
                Hello Sir/Mam Welcome to Bank 
                   
                Press 1 For Registration 
                Press 2 For Diposit
                Press 3 For Withdraw 
                Press 4 For Balance 
                Press 5 For Statement
                Press 6 For Exit 
                  
                    """)

            if bank== "1":
                self.registration()
                      
            elif bank=="2":
                self.diposit() 
                print("Diposit Amount ")

            elif bank =="3":
                self.withdraw()
                # print("Withdraw Amount ")

            elif bank == "4" :
                self.balance()

            elif bank =="5":
                self.statment() 

            elif bank =="6":
                self.exit()
                break

            else:
             print("Press valid key ")
            
            
    def registration (self):
             self.Username=(input("Enter Your Name : "))
             self.mobile_number=(int(input("Enter your register Mobile Number : ")))
             self.data.append({self.Username:{'Mobile Number':self.mobile_number ,'Balance':self.balance}})
             add=str(self.data)
             print(add)
             apen=open('data.txt','+a')
             apen.write(add)
                    
    def diposit(self):
              # print("diposit amount=1000")
            amount=int(input("Enter the Amount : "))
            self.balance += amount
            print(f"Deposited {amount}. New balance is {self.balance}.")
            # import json

    def withdraw(self):
            amount=int(input("Enter your amount : "))

            if amount > self.balance:
                print("Insufficient balance.")
            else:
                self.balance -= amount
                print(f"Withdraw {amount}. New balance is {self.balance}.")

    def balance(self,balance):

            print("Your total balance is : ",balance)

            with open("balance.txt", "r") as file:
             data = file.readlines()
             for line in data:
            
              word = line.split()
              print (word)
            # self.balance

    def statment(self):
           self.statment

    def exit(self):
         print("Bye--Bye")
         self.exit



obj=Bank()
print(obj.__init__())
print(obj.menu())
# print(obj.registration())
# print(obj.diposit())
# print(obj.withdraw())
# print(obj.balance())
# print(obj.statment())
# print(obj.exit())
# print(Bank)

        
   